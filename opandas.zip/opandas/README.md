# opandas

**Optimized pandas wrapper** — faster CSV reading, smarter data cleaning, and richer descriptive statistics.

---

## Installation

### Option 1 — Install from local folder (recommended for now)

```bash
pip install /path/to/opandas
```

### Option 2 — Install in a fresh virtual environment (recommended)

```bash
# Step 1: Create a virtual environment
python3 -m venv opandas_env

# Step 2: Activate it
source opandas_env/bin/activate        # macOS / Linux
opandas_env\Scripts\activate           # Windows

# Step 3: Install opandas
pip install /path/to/opandas

# Step 4: (Optional) Install notebook + plotting extras
pip install /path/to/opandas[notebook]
```

### Option 3 — Editable install for development

```bash
pip install -e /path/to/opandas
```

### Dependencies installed automatically

| Package | Version | Purpose |
|---------|---------|---------|
| pandas | ≥ 2.0 | core DataFrame engine |
| numpy | ≥ 1.24 | numeric operations |
| pyarrow | ≥ 10.0 | fast CSV reading (Arrow engine) |

---

## Quick Start

```python
import opandas as op

# ── Read CSV (4× faster than pandas) ─────────────────────
df = op.read_csv("data.csv")               # auto-picks best engine
df = op.read_csv("data.csv", engine="arrow")    # force PyArrow
df = op.read_csv("data.csv", engine="chunked")  # chunked for huge files

# ── Clean data (one call pipeline) ───────────────────────
df = op.clean(df)                          # all steps in one copy
df = op.auto_cast_types(df)               # downcast dtypes → save RAM
df = op.parse_dates(df)                   # auto-detect & parse date cols
df = op.split_column(df, "Date", "-",     # split one col into many
                     new_columns=["Year", "Month", "Day"])
df = op.drop_nulls(df, col_threshold=0.9) # drop cols > 90% null
df = op.normalize_text_columns(df)        # strip + lowercase text
df = op.remove_duplicates(df)             # dedup rows

# ── Describe (richer than pandas .describe()) ─────────────
op.summary(df)              # shape, dtypes, nulls, stats, memory, dups
op.numeric_summary(df)      # + skew, kurtosis, IQR, outlier count, CV
op.missing_report(df)       # sorted null % table per column
op.categorical_summary(df)  # unique / top / entropy per string column
op.value_counts_all(df)     # top-N value counts for every cat column

# ── OFrame: all methods directly on the object ────────────
odf = op.OFrame(df)
odf.clean()
odf.summary()
odf.numeric_summary()
odf.missing_report()
odf.categorical_summary()
```

---

## Benchmark (NASDAQ100, 514K rows × 8 cols, 26 MB)

| Operation | pandas | opandas | Speedup |
|-----------|--------|---------|---------|
| `read_csv` | 195 ms | 36 ms | **5.4×** |
| `summary()` | 307 ms | 250 ms | **1.2×** |
| `auto_cast_types()` | — | 51% RAM saved | — |
| `missing_report()` | — | 21 ms | instant |

---

## Package Structure

```
opandas/
├── opandas/
│   ├── __init__.py      # public API
│   ├── reader.py        # optimized read_csv (arrow / chunked / pandas)
│   ├── cleaner.py       # auto_cast_types, parse_dates, split_column, clean …
│   ├── describe.py      # summary, numeric_summary, missing_report, categorical_summary
│   └── frame.py         # OFrame — DataFrame subclass with all opandas methods
├── pyproject.toml
├── setup.py
└── README.md
```

---

## License

MIT
