"""
Benchmark: pandas 2.2.2  vs  opandas 0.1.0
Test file: /Users/udacity/Downloads/test (2).csv

Tests:
  1. read_csv speed
  2. summarize / describe speed
"""

import time
import textwrap
import pandas as pd
import opandas as op

CSV_PATH = "/Users/udacity/Downloads/test (2).csv"
RUNS = 3  # average over N runs


def avg_time(fn, runs=RUNS):
    """Run fn() `runs` times and return (mean_seconds, last_result)."""
    times = []
    result = None
    for _ in range(runs):
        t0 = time.perf_counter()
        result = fn()
        times.append(time.perf_counter() - t0)
    return sum(times) / len(times), result


def fmt(seconds):
    return f"{seconds*1000:.1f} ms"


def speedup(base, fast):
    if fast == 0:
        return "N/A"
    return f"{base/fast:.2f}x"


# ════════════════════════════════════════════════════════════
# 1. READ CSV
# ════════════════════════════════════════════════════════════
print("\n" + "═"*60)
print("  BENCHMARK 1 — read_csv")
print("═"*60)

# pandas default
pd_read_time, pd_df = avg_time(lambda: pd.read_csv(CSV_PATH))

# opandas auto (arrow engine)
op_read_time, op_df = avg_time(lambda: op.read_csv(CSV_PATH, engine="auto"))

# opandas chunked (for reference)
op_chunked_time, _ = avg_time(lambda: op.read_csv(CSV_PATH, engine="chunked"))

print(f"  pandas  read_csv       : {fmt(pd_read_time)}")
print(f"  opandas read_csv (auto): {fmt(op_read_time)}  → speedup {speedup(pd_read_time, op_read_time)}")
print(f"  opandas read_csv (chunked): {fmt(op_chunked_time)}")
print(f"\n  Rows: {len(pd_df):,}   Cols: {len(pd_df.columns)}")


# ════════════════════════════════════════════════════════════
# 2. SUMMARIZE / DESCRIBE
# ════════════════════════════════════════════════════════════
print("\n" + "═"*60)
print("  BENCHMARK 2 — summarize / describe")
print("═"*60)

# pandas default describe (numeric only – apples-to-apples)
pd_desc_time, pd_desc = avg_time(lambda: pd_df.describe())

# pandas describe + isnull + duplicated  (what opandas summary does)
def pandas_full_summary(df):
    desc = df.describe()
    nulls = df.isnull().sum()
    dups  = df.duplicated().sum()
    mem   = df.memory_usage(deep=True).sum()
    return desc, nulls, dups, mem

pd_full_time, _ = avg_time(lambda: pandas_full_summary(pd_df))

# opandas summary (full overview dict)
op_sum_time, op_sum = avg_time(lambda: op.summary(op_df))

# opandas numeric_summary (extended stats — more info than describe)
op_num_time, op_num = avg_time(lambda: op.numeric_summary(op_df))

# opandas missing_report
op_miss_time, op_miss = avg_time(lambda: op.missing_report(op_df))

print(f"  pandas  .describe()                      : {fmt(pd_desc_time)}")
print(f"  pandas  describe+isnull+duplicated+memory: {fmt(pd_full_time)}")
print(f"  opandas summary()  [same 4 ops above]    : {fmt(op_sum_time)}  → speedup vs pandas full: {speedup(pd_full_time, op_sum_time)}")
print(f"  opandas numeric_summary() [+skew/kurt/IQR/outliers]: {fmt(op_num_time)}")
print(f"  opandas missing_report()                 : {fmt(op_miss_time)}")


# ════════════════════════════════════════════════════════════
# 3. CLEANING PIPELINE  (equivalent steps compared)
# ════════════════════════════════════════════════════════════
print("\n" + "═"*60)
print("  BENCHMARK 3 — data cleaning pipeline (equivalent steps)")
print("═"*60)

# pandas equivalent: dropna + dtype downcast + dedup (same 3 ops as opandas)
def pandas_clean_full(df):
    df = df.copy()
    # drop rows/cols with all nulls
    df = df.dropna(how="all")
    df = df.dropna(axis=1, how="all")
    # downcast numerics
    for col in df.select_dtypes(include="integer").columns:
        df[col] = pd.to_numeric(df[col], downcast="integer")
    for col in df.select_dtypes(include="float").columns:
        df[col] = pd.to_numeric(df[col], downcast="float")
    # dedup
    df = df.drop_duplicates()
    return df

pd_clean_time, pd_cleaned = avg_time(lambda: pandas_clean_full(pd_df))

# opandas clean() – same logical steps
op_clean_time, op_cleaned = avg_time(
    lambda: op.clean(op_df, cast_types=True, dates=False, nulls=True,
                     text=False, dedup=True)
)

print(f"  pandas  clean (dropna+downcast+dedup) : {fmt(pd_clean_time)}")
print(f"  opandas clean (cast+nulls+dedup)      : {fmt(op_clean_time)}  → speedup {speedup(pd_clean_time, op_clean_time)}")


# ════════════════════════════════════════════════════════════
# 4. SAMPLE OUTPUTS
# ════════════════════════════════════════════════════════════
print("\n" + "═"*60)
print("  SAMPLE — opandas summary()")
print("═"*60)
s = op.summary(op_df)
print(f"  Shape      : {s['shape']}")
print(f"  Memory     : {s['memory_mb']} MB")
print(f"  Duplicates : {s['duplicates']}")
print(f"\n  Null % per column:")
for col, pct in s['null_pct'].items():
    print(f"    {col:<30} {pct:>6.2f}%")

print("\n" + "═"*60)
print("  SAMPLE — opandas numeric_summary()")
print("═"*60)
print(op.numeric_summary(op_df).to_string())

print("\n" + "═"*60)
print("  SAMPLE — opandas missing_report()")
print("═"*60)
print(op.missing_report(op_df).to_string())

print("\n" + "═"*60)
print("  Done.")
print("═"*60 + "\n")
