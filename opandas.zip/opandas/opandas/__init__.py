"""
opandas - Optimized pandas wrapper
Provides faster CSV reading, data cleaning, and descriptive functions.
"""

from .reader import read_csv
from .cleaner import (
    auto_cast_types,
    parse_dates,
    split_column,
    drop_nulls,
    normalize_text_columns,
    remove_duplicates,
    clean,
)
from .describe import (
    summary,
    value_counts_all,
    missing_report,
    numeric_summary,
    categorical_summary,
)
from .frame import OFrame

__version__ = "0.1.0"
__all__ = [
    "read_csv",
    "auto_cast_types",
    "parse_dates",
    "split_column",
    "drop_nulls",
    "normalize_text_columns",
    "remove_duplicates",
    "clean",
    "summary",
    "value_counts_all",
    "missing_report",
    "numeric_summary",
    "categorical_summary",
    "OFrame",
]
