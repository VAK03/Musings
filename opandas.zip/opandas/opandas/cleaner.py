"""
opandas.cleaner
---------------
Data cleaning utilities optimized with vectorized operations.

Functions
---------
auto_cast_types        – infer and downcast column dtypes to save memory
parse_dates            – convert string columns to datetime
split_column           – split one column into multiple on a delimiter
drop_nulls             – drop rows/columns based on null thresholds
normalize_text_columns – strip, lowercase, and standardize text columns
remove_duplicates      – drop duplicate rows
clean                  – run a full cleaning pipeline in one call
"""

import re
import pandas as pd
import numpy as np


# ── dtype casting ──────────────────────────────────────────────────────────────

def auto_cast_types(df: pd.DataFrame, inplace: bool = False) -> pd.DataFrame:
    """
    Automatically downcast numeric columns and convert obvious categoricals.

    - int columns   → smallest int that fits (int8 … int64)
    - float columns → float32 where precision loss is negligible
    - object columns with low cardinality (< 50 % unique) → category

    Parameters
    ----------
    df      : DataFrame to process
    inplace : modify df in place (default False)

    Returns
    -------
    DataFrame with optimized dtypes
    """
    if not inplace:
        df = df.copy()

    n = max(len(df), 1)

    # Batch all integer columns in one go
    int_cols = df.select_dtypes(include="integer").columns.tolist()
    for col in int_cols:
        df[col] = pd.to_numeric(df[col], downcast="integer")

    # Batch all float columns in one go
    float_cols = df.select_dtypes(include="float").columns.tolist()
    for col in float_cols:
        df[col] = pd.to_numeric(df[col], downcast="float")

    # Object columns: use a small sample (500 rows) to decide strategy quickly
    obj_cols = df.select_dtypes(include="object").columns.tolist()
    for col in obj_cols:
        sample = df[col].dropna().head(500)
        if sample.empty:
            continue

        # Check numeric on sample only (fast)
        sample_num = pd.to_numeric(sample, errors="coerce")
        if sample_num.notna().sum() / len(sample) > 0.8:
            # Column is numeric — convert the full series once
            df[col] = pd.to_numeric(df[col], errors="coerce", downcast="float")
        else:
            # Check cardinality: nunique on full col, but use approx via sample first
            sample_uniq_rate = sample.nunique() / len(sample)
            if sample_uniq_rate < 0.5:
                # Likely low-cardinality → category (full nunique confirm)
                n_unique = df[col].nunique(dropna=True)
                if n_unique / n < 0.5:
                    df[col] = df[col].astype("category")

    return df


# ── date parsing ───────────────────────────────────────────────────────────────

# Common date format patterns to try in order (fastest first)
_DATE_FORMATS = [
    "%Y-%m-%d",
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%Y/%m/%d",
    "%d-%m-%Y",
    "%m-%d-%Y",
    "%Y%m%d",
    "%d %b %Y",
    "%d %B %Y",
    "%b %d, %Y",
]


def _try_parse_date(series: pd.Series) -> pd.Series | None:
    """Attempt fast date parsing; return None if column is not date-like."""
    sample = series.dropna().head(100).astype(str)
    if sample.empty:
        return None

    for fmt in _DATE_FORMATS:
        try:
            parsed = pd.to_datetime(series, format=fmt, errors="raise")
            return parsed
        except Exception:
            continue

    # Last resort: infer_datetime_format (slower)
    try:
        parsed = pd.to_datetime(series, infer_datetime_format=True, errors="coerce")
        if parsed.notna().sum() / max(len(series), 1) > 0.5:
            return parsed
    except Exception:
        pass

    return None


def parse_dates(
    df: pd.DataFrame,
    columns: list[str] | None = None,
    auto_detect: bool = True,
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Parse date columns to datetime64.

    Parameters
    ----------
    df          : DataFrame to process
    columns     : explicit list of columns to parse; if None and auto_detect=True,
                  columns are guessed by name heuristics
    auto_detect : when True and columns=None, detect date-like column names
    inplace     : modify df in place

    Returns
    -------
    DataFrame with datetime columns
    """
    if not inplace:
        df = df.copy()

    date_name_pattern = re.compile(
        r"(date|time|dt|year|month|day|timestamp|dob|birth)", re.IGNORECASE
    )

    if columns is None and auto_detect:
        columns = [
            c for c in df.columns
            if df[c].dtype == object and date_name_pattern.search(str(c))
        ]

    if not columns:
        return df

    for col in columns:
        if col not in df.columns:
            continue
        parsed = _try_parse_date(df[col])
        if parsed is not None:
            df[col] = parsed

    return df


# ── column splitting ───────────────────────────────────────────────────────────

def split_column(
    df: pd.DataFrame,
    column: str,
    delimiter: str = " ",
    new_columns: list[str] | None = None,
    drop_original: bool = True,
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Split a single column into multiple columns on a delimiter.

    Parameters
    ----------
    df            : DataFrame to process
    column        : name of the column to split
    delimiter     : string or regex to split on (default single space)
    new_columns   : names for the resulting columns; if None, auto-named
                    as <column>_0, <column>_1, …
    drop_original : drop the source column after splitting
    inplace       : modify df in place

    Returns
    -------
    DataFrame with split columns appended
    """
    if column not in df.columns:
        raise KeyError(f"Column '{column}' not found in DataFrame.")

    if not inplace:
        df = df.copy()

    # pandas str.split with expand=True is the fastest path for most cases
    # Limit number of splits upfront when new_columns is specified (avoids extra work)
    n_splits = len(new_columns) - 1 if new_columns else -1
    split_df = df[column].astype(str).str.split(delimiter, n=n_splits if n_splits > 0 else -1, expand=True)

    if new_columns:
        n = min(len(new_columns), split_df.shape[1])
        split_df = split_df.iloc[:, :n]
        split_df.columns = new_columns[:n]
    else:
        split_df.columns = [f"{column}_{i}" for i in range(split_df.shape[1])]

    df = pd.concat([df, split_df], axis=1)

    if drop_original:
        df.drop(columns=[column], inplace=True)

    return df


# ── null handling ──────────────────────────────────────────────────────────────

def drop_nulls(
    df: pd.DataFrame,
    row_threshold: float = 1.0,
    col_threshold: float = 1.0,
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Drop rows and/or columns that exceed null thresholds.

    Parameters
    ----------
    df              : DataFrame to process
    row_threshold   : drop rows where fraction of nulls >= this value (0–1)
    col_threshold   : drop columns where fraction of nulls >= this value (0–1)
    inplace         : modify df in place

    Returns
    -------
    Cleaned DataFrame
    """
    if not inplace:
        df = df.copy()

    if col_threshold < 1.0:
        null_frac_cols = df.isnull().mean()
        cols_to_drop = null_frac_cols[null_frac_cols >= col_threshold].index
        df.drop(columns=cols_to_drop, inplace=True)

    if row_threshold < 1.0:
        null_frac_rows = df.isnull().mean(axis=1)
        df = df[null_frac_rows < row_threshold]

    return df


# ── text normalization ─────────────────────────────────────────────────────────

def normalize_text_columns(
    df: pd.DataFrame,
    columns: list[str] | None = None,
    lowercase: bool = True,
    strip: bool = True,
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Normalize text in object/category columns.

    Parameters
    ----------
    df        : DataFrame to process
    columns   : columns to normalize; if None, all object columns
    lowercase : convert to lowercase
    strip     : strip leading/trailing whitespace
    inplace   : modify df in place

    Returns
    -------
    DataFrame with normalized text
    """
    if not inplace:
        df = df.copy()

    if columns is None:
        columns = df.select_dtypes(include=["object", "category"]).columns.tolist()

    for col in columns:
        if col not in df.columns:
            continue
        s = df[col].astype(str)
        if strip:
            s = s.str.strip()
        if lowercase:
            s = s.str.lower()
        # Replace blank strings with NaN
        s = s.replace({"nan": np.nan, "": np.nan, "none": np.nan})
        df[col] = s

    return df


# ── duplicates ─────────────────────────────────────────────────────────────────

def remove_duplicates(
    df: pd.DataFrame,
    subset: list[str] | None = None,
    keep: str = "first",
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Remove duplicate rows.

    Parameters
    ----------
    df     : DataFrame to process
    subset : columns to consider for duplicates; None = all columns
    keep   : 'first', 'last', or False
    inplace: modify df in place

    Returns
    -------
    DataFrame with duplicates removed
    """
    if not inplace:
        df = df.copy()
    return df.drop_duplicates(subset=subset, keep=keep)


# ── full pipeline ──────────────────────────────────────────────────────────────

def clean(
    df: pd.DataFrame,
    cast_types: bool = True,
    dates: bool = True,
    date_columns: list[str] | None = None,
    nulls: bool = True,
    row_null_threshold: float = 1.0,
    col_null_threshold: float = 1.0,
    text: bool = True,
    dedup: bool = True,
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Run a full cleaning pipeline on a DataFrame.

    Steps (all optional):
      1. auto_cast_types
      2. parse_dates
      3. drop_nulls
      4. normalize_text_columns
      5. remove_duplicates

    All steps run inplace on a single copy to avoid redundant allocations.

    Parameters
    ----------
    df                  : DataFrame to clean
    cast_types          : run dtype optimization
    dates               : run date parsing
    date_columns        : explicit date columns (passed to parse_dates)
    nulls               : run null dropping
    row_null_threshold  : row null fraction threshold
    col_null_threshold  : column null fraction threshold
    text                : run text normalization
    dedup               : run duplicate removal
    inplace             : modify df in place (single copy)

    Returns
    -------
    Cleaned DataFrame
    """
    # Take at most ONE copy across the whole pipeline
    if not inplace:
        df = df.copy()

    if cast_types:
        auto_cast_types(df, inplace=True)

    if dates:
        parse_dates(df, columns=date_columns, auto_detect=True, inplace=True)

    if nulls:
        df = drop_nulls(
            df,
            row_threshold=row_null_threshold,
            col_threshold=col_null_threshold,
            inplace=True,
        )

    if text:
        normalize_text_columns(df, inplace=True)

    if dedup:
        df = remove_duplicates(df, inplace=True)

    return df
