"""
opandas.reader
--------------
Optimized CSV reading with automatic engine selection.

Strategy:
  1. Try pyarrow engine first (fastest, columnar reads)
  2. Fall back to pandas c engine with low_memory=False
  3. Chunked reading for large files (> CHUNK_THRESHOLD bytes)
"""

import os
import pandas as pd

# Files larger than 50 MB get chunked reads
CHUNK_THRESHOLD = 50 * 1024 * 1024  # 50 MB

# Check pyarrow availability once at import time
try:
    import pyarrow.csv as pa_csv
    import pyarrow as pa
    _HAS_PYARROW = True
except ImportError:
    _HAS_PYARROW = False


def _read_with_pyarrow(filepath, **kwargs):
    """Read CSV using pyarrow, return a pandas DataFrame."""
    # Map common pandas kwargs to pyarrow equivalents
    read_options = pa_csv.ReadOptions()
    parse_options = pa_csv.ParseOptions()
    convert_options = pa_csv.ConvertOptions()

    # Handle delimiter
    delimiter = kwargs.get("sep", kwargs.get("delimiter", ","))
    if delimiter and len(delimiter) == 1:
        parse_options = pa_csv.ParseOptions(delimiter=delimiter)

    # Handle column selection
    include_cols = kwargs.get("usecols", None)
    if include_cols:
        convert_options = pa_csv.ConvertOptions(include_columns=list(include_cols))

    # Handle na_values
    na_vals = kwargs.get("na_values", None)
    if na_vals:
        if isinstance(na_vals, str):
            na_vals = [na_vals]
        convert_options = pa_csv.ConvertOptions(
            null_values=list(na_vals),
            include_columns=list(include_cols) if include_cols else None,
        )

    table = pa_csv.read_csv(
        filepath,
        read_options=read_options,
        parse_options=parse_options,
        convert_options=convert_options,
    )
    return table.to_pandas()


def _read_chunked(filepath, chunksize=100_000, **kwargs):
    """Read large CSV in chunks and concatenate."""
    kwargs.setdefault("low_memory", False)
    chunks = []
    for chunk in pd.read_csv(filepath, chunksize=chunksize, **kwargs):
        chunks.append(chunk)
    return pd.concat(chunks, ignore_index=True)


def read_csv(filepath, engine="auto", chunksize=100_000, **kwargs):
    """
    Read a CSV file into a pandas DataFrame, optimized for speed.

    Parameters
    ----------
    filepath : str
        Path to the CSV file.
    engine : str, optional
        'auto'    – pick best available engine (default)
        'arrow'   – force pyarrow engine
        'pandas'  – force pandas c engine
        'chunked' – force chunked pandas reads
    chunksize : int, optional
        Rows per chunk when engine='chunked' or file exceeds CHUNK_THRESHOLD.
        Default 100_000.
    **kwargs
        Additional keyword arguments forwarded to the underlying reader.

    Returns
    -------
    pandas.DataFrame
    """
    file_size = os.path.getsize(filepath) if os.path.exists(filepath) else 0

    if engine == "auto":
        if _HAS_PYARROW:
            engine = "arrow"
        elif file_size > CHUNK_THRESHOLD:
            engine = "chunked"
        else:
            engine = "pandas"

    if engine == "arrow":
        if not _HAS_PYARROW:
            # Graceful fallback
            engine = "chunked" if file_size > CHUNK_THRESHOLD else "pandas"
        else:
            try:
                return _read_with_pyarrow(filepath, **kwargs)
            except Exception:
                # Fall through to pandas on any arrow error
                engine = "chunked" if file_size > CHUNK_THRESHOLD else "pandas"

    if engine == "chunked":
        return _read_chunked(filepath, chunksize=chunksize, **kwargs)

    # Default: pandas c engine
    kwargs.setdefault("low_memory", False)
    return pd.read_csv(filepath, **kwargs)
