"""
opandas.frame
-------------
OFrame: a thin subclass of pandas DataFrame that exposes
all opandas cleaning and descriptive methods directly on the object.
"""

import pandas as pd
from . import cleaner, describe as _describe


class OFrame(pd.DataFrame):
    """
    OFrame – pandas DataFrame with opandas superpowers.

    All opandas cleaning and descriptive functions are available
    as methods on this class.

    Examples
    --------
    >>> import opandas as op
    >>> df = op.read_csv("data.csv")
    >>> odf = op.OFrame(df)
    >>> odf.clean()
    >>> odf.summary()
    >>> odf.numeric_summary()
    """

    # Required so that pandas operations return OFrame, not plain DataFrame
    @property
    def _constructor(self):
        return OFrame

    # ── cleaning methods ──────────────────────────────────────────────────────

    def auto_cast_types(self, inplace=False):
        return cleaner.auto_cast_types(self, inplace=inplace)

    def parse_dates(self, columns=None, auto_detect=True, inplace=False):
        return cleaner.parse_dates(self, columns=columns, auto_detect=auto_detect, inplace=inplace)

    def split_column(self, column, delimiter=" ", new_columns=None, drop_original=True, inplace=False):
        return cleaner.split_column(
            self, column=column, delimiter=delimiter,
            new_columns=new_columns, drop_original=drop_original, inplace=inplace
        )

    def drop_nulls(self, row_threshold=1.0, col_threshold=1.0, inplace=False):
        return cleaner.drop_nulls(
            self, row_threshold=row_threshold, col_threshold=col_threshold, inplace=inplace
        )

    def normalize_text_columns(self, columns=None, lowercase=True, strip=True, inplace=False):
        return cleaner.normalize_text_columns(
            self, columns=columns, lowercase=lowercase, strip=strip, inplace=inplace
        )

    def remove_duplicates(self, subset=None, keep="first", inplace=False):
        return cleaner.remove_duplicates(self, subset=subset, keep=keep, inplace=inplace)

    def clean(self, cast_types=True, dates=True, date_columns=None,
              nulls=True, row_null_threshold=1.0, col_null_threshold=1.0,
              text=True, dedup=True, inplace=False):
        return cleaner.clean(
            self, cast_types=cast_types, dates=dates, date_columns=date_columns,
            nulls=nulls, row_null_threshold=row_null_threshold,
            col_null_threshold=col_null_threshold,
            text=text, dedup=dedup, inplace=inplace
        )

    # ── descriptive methods ───────────────────────────────────────────────────

    def summary(self):
        return _describe.summary(self)

    def missing_report(self):
        return _describe.missing_report(self)

    def numeric_summary(self):
        return _describe.numeric_summary(self)

    def categorical_summary(self, top_n=5):
        return _describe.categorical_summary(self, top_n=top_n)

    def value_counts_all(self, top_n=10, normalize=False):
        return _describe.value_counts_all(self, top_n=top_n, normalize=normalize)
