"""
opandas.describe
----------------
Fast descriptive statistics beyond pandas default .describe().

Functions
---------
summary             – unified overview (shape, dtypes, nulls, stats)
value_counts_all    – value counts for all categorical/object columns
missing_report      – detailed null analysis per column
numeric_summary     – extended numeric stats (skew, kurtosis, IQR, outliers)
categorical_summary – top-N counts + entropy for categorical columns
"""

import pandas as pd
import numpy as np


# ── helpers ────────────────────────────────────────────────────────────────────

def _iqr_outliers(series: pd.Series) -> int:
    """Count outliers using 1.5 × IQR rule."""
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    mask = (series < q1 - 1.5 * iqr) | (series > q3 + 1.5 * iqr)
    return int(mask.sum())


def _entropy(series: pd.Series) -> float:
    """Shannon entropy (bits) of a categorical/object series."""
    counts = series.value_counts(normalize=True, dropna=True)
    if counts.empty:
        return 0.0
    return float(-(counts * np.log2(counts + 1e-12)).sum())


# ── public API ─────────────────────────────────────────────────────────────────

def summary(df: pd.DataFrame) -> dict:
    """
    High-level overview of a DataFrame.

    Returns a dict with:
      - shape        : (rows, cols)
      - dtypes       : Series of dtype per column
      - null_counts  : Series of null count per column
      - null_pct     : Series of null % per column
      - numeric_stats: DataFrame from pandas describe() on numeric cols
      - memory_mb    : total memory usage in MB
      - duplicates   : number of fully duplicate rows

    Parameters
    ----------
    df : DataFrame to summarize

    Returns
    -------
    dict
    """
    # Single pass null computation
    null_counts = df.isnull().sum()
    n = len(df)
    null_pct = (null_counts / n * 100).round(2)

    # Memory: use deep=False for speed; only go deep on object cols
    obj_cols = df.select_dtypes(include="object").columns
    mem_basic = df.memory_usage(deep=False).sum()
    mem_obj = sum(df[c].memory_usage(deep=True) for c in obj_cols) if len(obj_cols) else 0
    mem_mb = (mem_basic + mem_obj) / 1024 ** 2

    numeric_cols = df.select_dtypes(include="number")
    numeric_stats = numeric_cols.describe().T if not numeric_cols.empty else pd.DataFrame()

    return {
        "shape": df.shape,
        "dtypes": df.dtypes,
        "null_counts": null_counts,
        "null_pct": null_pct,
        "numeric_stats": numeric_stats,
        "memory_mb": round(mem_mb, 3),
        "duplicates": int(df.duplicated().sum()),
    }


def missing_report(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detailed missing-value report per column.

    Returns a DataFrame with columns:
      dtype, total, missing, missing_pct, non_missing, non_missing_pct

    Parameters
    ----------
    df : DataFrame to analyse

    Returns
    -------
    pd.DataFrame sorted by missing_pct descending
    """
    total = len(df)
    missing = df.isnull().sum()
    non_missing = total - missing
    report = pd.DataFrame(
        {
            "dtype": df.dtypes,
            "total": total,
            "missing": missing,
            "missing_pct": (missing / total * 100).round(2),
            "non_missing": non_missing,
            "non_missing_pct": (non_missing / total * 100).round(2),
        }
    )
    return report.sort_values("missing_pct", ascending=False)


def numeric_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Extended numeric statistics.

    Columns returned:
      count, mean, std, min, 25%, 50%, 75%, max,
      skewness, kurtosis, iqr, outliers (IQR rule), cv (coef. of variation)

    Parameters
    ----------
    df : DataFrame (only numeric columns are analysed)

    Returns
    -------
    pd.DataFrame with one row per numeric column
    """
    num_df = df.select_dtypes(include="number")
    if num_df.empty:
        return pd.DataFrame()

    # Single quantile call for base stats + IQR
    base = num_df.describe().T
    q25 = num_df.quantile(0.25)
    q75 = num_df.quantile(0.75)
    iqr = q75 - q25

    # Vectorized skew/kurt via numpy for speed
    vals = num_df.values.astype(np.float64)
    n = vals.shape[0]
    means = np.nanmean(vals, axis=0)
    stds = np.nanstd(vals, axis=0, ddof=1)

    with np.errstate(divide="ignore", invalid="ignore"):
        skewness = np.where(stds > 0, np.nanmean(((vals - means) / stds) ** 3, axis=0), 0.0)
        kurtosis = np.where(stds > 0, np.nanmean(((vals - means) / stds) ** 4, axis=0) - 3, 0.0)

    base["skewness"] = np.round(skewness, 4)
    base["kurtosis"] = np.round(kurtosis, 4)
    base["iqr"] = iqr.values
    base["outliers"] = num_df.apply(_iqr_outliers)
    base["cv"] = np.where(means != 0, np.round(stds / np.abs(means), 4), np.nan)

    return base


def categorical_summary(df: pd.DataFrame, top_n: int = 5) -> pd.DataFrame:
    """
    Summary for categorical/object columns.

    Columns returned:
      dtype, unique, top_value, top_count, top_pct, entropy

    Parameters
    ----------
    df    : DataFrame to analyse
    top_n : number of top values to list in the 'top_values' column

    Returns
    -------
    pd.DataFrame with one row per categorical column
    """
    cat_cols = df.select_dtypes(include=["object", "category"]).columns
    if cat_cols.empty:
        return pd.DataFrame()

    rows = []
    for col in cat_cols:
        s = df[col]
        vc = s.value_counts(dropna=True)
        top_val = vc.index[0] if not vc.empty else np.nan
        top_cnt = int(vc.iloc[0]) if not vc.empty else 0
        top_pct = round(top_cnt / len(s) * 100, 2) if len(s) > 0 else 0.0
        top_values = vc.head(top_n).to_dict()

        rows.append(
            {
                "column": col,
                "dtype": str(s.dtype),
                "unique": s.nunique(dropna=True),
                "top_value": top_val,
                "top_count": top_cnt,
                "top_pct": top_pct,
                "entropy": round(_entropy(s), 4),
                f"top_{top_n}_values": top_values,
            }
        )

    return pd.DataFrame(rows).set_index("column")


def value_counts_all(
    df: pd.DataFrame, top_n: int = 10, normalize: bool = False
) -> dict[str, pd.Series]:
    """
    Value counts for every categorical/object column.

    Parameters
    ----------
    df        : DataFrame to analyse
    top_n     : return only the top N values per column
    normalize : return proportions instead of counts

    Returns
    -------
    dict mapping column name → pd.Series of counts (or proportions)
    """
    cat_cols = df.select_dtypes(include=["object", "category"]).columns
    return {
        col: df[col].value_counts(normalize=normalize, dropna=True).head(top_n)
        for col in cat_cols
    }
