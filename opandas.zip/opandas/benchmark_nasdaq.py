"""
Benchmark: pandas 2.2.2  vs  opandas 0.1.0
Test file: /Users/udacity/Downloads/NASDAQ100_Historical_Data.csv

514,075 rows × 8 cols (Ticker[str], Date[str→date], OHLC[float], Volume[int])

Tests:
  1. read_csv speed
  2. summarize / describe speed
  3. data cleaning pipeline
  4. opandas-specific: date parsing, split_column, missing_report
"""

import time
import pandas as pd
import opandas as op

CSV_PATH = "/Users/udacity/Downloads/NASDAQ100_Historical_Data.csv"
RUNS = 3


def avg_time(fn, runs=RUNS):
    times = []
    result = None
    for _ in range(runs):
        t0 = time.perf_counter()
        result = fn()
        times.append(time.perf_counter() - t0)
    return sum(times) / len(times), result


def fmt(s):
    return f"{s*1000:.1f} ms"


def speedup(base, fast):
    return f"{base/fast:.2f}x" if fast > 0 else "N/A"


# ════════════════════════════════════════════════════════════
# 0. FILE INFO
# ════════════════════════════════════════════════════════════
import os
size_mb = os.path.getsize(CSV_PATH) / 1024**2
print("\n" + "═"*65)
print("  FILE INFO")
print("═"*65)
print(f"  Path : {CSV_PATH}")
print(f"  Size : {size_mb:.1f} MB")


# ════════════════════════════════════════════════════════════
# 1. READ CSV
# ════════════════════════════════════════════════════════════
print("\n" + "═"*65)
print("  BENCHMARK 1 — read_csv  (avg of 3 runs)")
print("═"*65)

pd_read_time,  pd_df  = avg_time(lambda: pd.read_csv(CSV_PATH))
op_read_time,  op_df  = avg_time(lambda: op.read_csv(CSV_PATH, engine="auto"))
op_chunk_time, _      = avg_time(lambda: op.read_csv(CSV_PATH, engine="chunked", chunksize=100_000))

print(f"  pandas  read_csv (c engine)      : {fmt(pd_read_time)}")
print(f"  opandas read_csv (arrow engine)  : {fmt(op_read_time)}  → {speedup(pd_read_time, op_read_time)} faster")
print(f"  opandas read_csv (chunked)       : {fmt(op_chunk_time)}")
print(f"\n  Rows : {len(pd_df):,}   Cols : {len(pd_df.columns)}")
print(f"  Columns: {list(pd_df.columns)}")


# ════════════════════════════════════════════════════════════
# 2. SUMMARIZE / DESCRIBE
# ════════════════════════════════════════════════════════════
print("\n" + "═"*65)
print("  BENCHMARK 2 — summarize / describe")
print("═"*65)

# pandas: describe + isnull + duplicated + memory (same ops as opandas summary)
def pandas_full_summary(df):
    desc  = df.describe(include="all")
    nulls = df.isnull().sum()
    dups  = df.duplicated().sum()
    mem   = df.memory_usage(deep=True).sum()
    return desc, nulls, dups, mem

pd_desc_time, _   = avg_time(lambda: pd_df.describe(include="all"))
pd_full_time, _   = avg_time(lambda: pandas_full_summary(pd_df))
op_sum_time,  s   = avg_time(lambda: op.summary(op_df))
op_num_time,  _   = avg_time(lambda: op.numeric_summary(op_df))
op_miss_time, _   = avg_time(lambda: op.missing_report(op_df))
op_cat_time,  _   = avg_time(lambda: op.categorical_summary(op_df))

print(f"  pandas  describe(all)                       : {fmt(pd_desc_time)}")
print(f"  pandas  describe+isnull+duplicated+memory   : {fmt(pd_full_time)}")
print(f"  opandas summary()      [same 4 ops]         : {fmt(op_sum_time)}  → {speedup(pd_full_time, op_sum_time)} vs pandas full")
print(f"  opandas numeric_summary() [+skew/kurt/IQR]  : {fmt(op_num_time)}")
print(f"  opandas missing_report()                    : {fmt(op_miss_time)}")
print(f"  opandas categorical_summary()               : {fmt(op_cat_time)}")


# ════════════════════════════════════════════════════════════
# 3. CLEANING PIPELINE (equivalent steps)
# ════════════════════════════════════════════════════════════
print("\n" + "═"*65)
print("  BENCHMARK 3 — data cleaning pipeline (equivalent steps)")
print("═"*65)

def pandas_clean_full(df):
    df = df.copy()
    # drop rows/cols where everything is null
    df = df.dropna(how="all")
    df = df.dropna(axis=1, how="all")
    # downcast numerics
    for col in df.select_dtypes(include="integer").columns:
        df[col] = pd.to_numeric(df[col], downcast="integer")
    for col in df.select_dtypes(include="float").columns:
        df[col] = pd.to_numeric(df[col], downcast="float")
    # parse dates manually
    df["Date"] = pd.to_datetime(df["Date"], format="%Y-%m-%d", errors="coerce")
    # strip text
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].str.strip()
    # dedup
    df = df.drop_duplicates()
    return df

def opandas_clean_full(df):
    return op.clean(
        df,
        cast_types=True,
        dates=True,
        date_columns=["Date"],
        nulls=True,
        text=True,
        dedup=True,
    )

pd_clean_time,  pd_cleaned = avg_time(lambda: pandas_clean_full(pd_df))
op_clean_time,  op_cleaned = avg_time(lambda: opandas_clean_full(op_df))

print(f"  pandas  clean (manual 5 steps)  : {fmt(pd_clean_time)}")
print(f"  opandas clean() [same 5 steps]  : {fmt(op_clean_time)}  → {speedup(pd_clean_time, op_clean_time)} faster")


# ════════════════════════════════════════════════════════════
# 4. OPANDAS-SPECIFIC FEATURES
# ════════════════════════════════════════════════════════════
print("\n" + "═"*65)
print("  BENCHMARK 4 — opandas-specific features")
print("═"*65)

# 4a. Date parsing alone
pd_date_time, _ = avg_time(
    lambda: pd_df.assign(Date=pd.to_datetime(pd_df["Date"], format="%Y-%m-%d", errors="coerce"))
)
op_date_time, _ = avg_time(
    lambda: op.parse_dates(op_df.copy(), columns=["Date"])
)
print(f"  parse_dates — pandas manual    : {fmt(pd_date_time)}")
print(f"  parse_dates — opandas          : {fmt(op_date_time)}  → {speedup(pd_date_time, op_date_time)}")

# 4b. auto_cast_types alone
pd_cast_time, _ = avg_time(lambda: (
    pd_df.copy().pipe(lambda d: d.assign(
        **{c: pd.to_numeric(d[c], downcast="integer")
           for c in d.select_dtypes(include="integer").columns},
        **{c: pd.to_numeric(d[c], downcast="float")
           for c in d.select_dtypes(include="float").columns},
    ))
))
op_cast_time, _ = avg_time(lambda: op.auto_cast_types(op_df.copy()))
print(f"  auto_cast_types — pandas manual: {fmt(pd_cast_time)}")
print(f"  auto_cast_types — opandas      : {fmt(op_cast_time)}  → {speedup(pd_cast_time, op_cast_time)}")

# 4c. split_column (Ticker has no delimiter, so split Date by "-" as demo)
op_split_time, split_df = avg_time(
    lambda: op.split_column(op_df.copy(), column="Date",
                            delimiter="-", new_columns=["Year","Month","Day"])
)
print(f"  split_column('Date','-')        : {fmt(op_split_time)}  (opandas only)")


# ════════════════════════════════════════════════════════════
# 5. SAMPLE OUTPUTS
# ════════════════════════════════════════════════════════════
print("\n" + "═"*65)
print("  SAMPLE — opandas summary()")
print("═"*65)
print(f"  Shape      : {s['shape']}")
print(f"  Memory     : {s['memory_mb']} MB")
print(f"  Duplicates : {s['duplicates']}")
print(f"\n  Null % per column:")
for col, pct in s["null_pct"].items():
    bar = "█" * int(pct / 2) if pct > 0 else "·"
    print(f"    {col:<20} {pct:>6.2f}%  {bar}")

print("\n" + "═"*65)
print("  SAMPLE — opandas numeric_summary()")
print("═"*65)
print(op.numeric_summary(op_df).to_string())

print("\n" + "═"*65)
print("  SAMPLE — opandas missing_report()")
print("═"*65)
print(op.missing_report(op_df).to_string())

print("\n" + "═"*65)
print("  SAMPLE — opandas categorical_summary()")
print("═"*65)
print(op.categorical_summary(op_df).to_string())

print("\n" + "═"*65)
print("  SAMPLE — split_column('Date', '-') → Year / Month / Day")
print("═"*65)
print(split_df[["Year", "Month", "Day"]].head(8).to_string())

print("\n" + "═"*65)
print("  SAMPLE — auto_cast_types: dtype before vs after")
print("═"*65)
casted = op.auto_cast_types(op_df.copy())
mem_before = op_df.memory_usage(deep=True).sum() / 1024**2
mem_after  = casted.memory_usage(deep=True).sum() / 1024**2
print(f"  Memory before cast : {mem_before:.2f} MB")
print(f"  Memory after cast  : {mem_after:.2f} MB  (saved {mem_before-mem_after:.2f} MB)")
print("\n  dtype changes:")
for col in op_df.columns:
    before = str(op_df[col].dtype)
    after  = str(casted[col].dtype)
    flag = " ← optimized" if before != after else ""
    print(f"    {col:<25} {before:<12} → {after}{flag}")

print("\n" + "═"*65)
print("  Done.")
print("═"*65 + "\n")
