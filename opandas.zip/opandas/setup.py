from setuptools import setup, find_packages

setup(
    name="opandas",
    version="0.1.0",
    description="Optimized pandas wrapper with fast CSV reading, data cleaning, and descriptive functions",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "pandas>=2.0",
        "numpy>=1.24",
        "pyarrow>=10.0",
        "scipy>=1.10",
    ],
)
